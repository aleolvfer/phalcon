docker pull phalconphp/ubuntu-16.04:php-7.2
docker run -p 8080:80 -v $(pwd):/app -v $(pwd)/docker/nginx.conf:/etc/nginx/sites-enabled/default:ro -d phalconphp/ubuntu-16.04:php-7.2