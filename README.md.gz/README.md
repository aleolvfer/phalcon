### Phalcon Init

`sudo chmod +x install.sh`
`./install`

`Open http://localhost:8080/`
